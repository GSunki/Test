module.exports = {
  aws_table_name: 'tbl_board',
  aws_local_config: {
    region:'local',
    endpoint: 'http://localhost:8000'
  },
  aws_remote_config: {
    accessKeyId:'AKIA4Q7CGLBKKD5ODO7R',
    secretAccessKey:'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',
    region: 'us-east-2'
  }
}
