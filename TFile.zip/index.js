var bodyParser = require('body-parser');
var AWS = require("aws-sdk");

const config =require('./config/config.js');
const express = require('express');
const app = express();

const server = app.listen(3000, () => {
  console.log('Start Server : localhost:3000');
});

exports.handler =  async function(event, context) {
  app.set('views',__dirname+'/views');
  app.set('view engine','ejs');
  app.engine('html', require('ejs').renderFile);
  app.use(bodyParser.json());
  app.use(bodyParser.urlencoded({extended : true}));

  //get 모음
  app.get('/', function(req, res){
    res.render('index.html')
  })

  app.get('/BoardList', function(req, res){
    res.render('BoardList.html')
  })

  app.post('/BoardWriteBack', (req, res, next) => {
    AWS.config.update(config.aws_remote_config);
    const docClient = new AWS.DynamoDB.DocumentClient();
    const params = {
      TableName: config.aws_table_name,
      Item:{
        bno:Number(req.body.bno),
        title:req.body.title,
        content:req.body.content,
        writer:req.body.writer
      }
    };

    docClient.put(params,function(err,data){
      if(err){
        console.log(err);
        res.send({
          success: false,
          message: 'Error: Server error'
        });
      } else{
        console.log('data', data);
        const {Items} = data;
        res.render('/list')
      }
    });
  });
  
    app.get('/list', (req,res,next) => {
      AWS.config.update(config.aws_remote_config);
      const docClient = new AWS.DynamoDB.DocumentClient();
      const params = {
        TableName: config.aws_table_name
      };

      docClient.scan(params, function(err, data){
        if(err){
          res.send({
            success: false,
            message: 'Error: Server error'
          });
        } else {
          const { Items } = data;
          res.send({
            Items
          });
        }
      });
    }); //

    app.get('/BoardWrite', function(req, res){
      res.render('BoardWrite.html')
    })
}
