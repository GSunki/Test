var AWS = require("aws-sdk");
const config = require('./config/config.js');

app.get('/api/add', (req, res, next) => {
  AWS.config.update(config.aws_remote_config);
  const docClient = new AWS.DynamoDB.DocumentClient();
  const params = {
    TableName: config.aws_table_name,
    Item:{
      bno:'2',
      title:'제목2',
      content:'내용2',
    }
  };

  docClient.put(params,function(err,data){
    if(err){
      console.log(err);
      res.send({
        success: false;
        message: 'Error: Server error'
      });
    } else{
      console.log('data', data);
      const {Items} = data;
      res.send({
        success: true;
        message:'Added Data'
      });
    }
  });
});
