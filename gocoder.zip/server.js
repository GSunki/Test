var bodyParser = require('body-parser');
var AWS = require("aws-sdk");

var Arraybno = [];
var Arraytitle = [];
var Arraycontent = [];
var Arraywriter = [];

const config =require('./config/config.js');
const express = require('express');
const app = express();

const server = app.listen(3000, () => {
  console.log('Start Server : localhost:3000');
});

app.set('views',__dirname+'/views');
app.set('view engine','ejs');
app.engine('html', require('ejs').renderFile);
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended : true}));

app.get('/', function(req, res){
  res.render('index.html')
})

app.get('/BoardList', function(req, res){
  res.render('BoardList.ejs')
})

app.get('/dum', function(req, res){
  res.render('index3.html')
})

app.get('/BoardUpdate', function(req, res){
  res.render('BoardUpdate.ejs')
})

app.get('/BoardDelete', function(req, res){
  res.render('BoardDelete.ejs')
})

app.get('/BoardView/:num', function(req, res){
  res.render('BoardView.ejs', {num: req.params.num})
})

app.post('/BoardWriteBack', (req, res, next) => {
  AWS.config.update(config.aws_remote_config);
  const docClient = new AWS.DynamoDB.DocumentClient();
  const params = {
    TableName: config.aws_table_name,
    Item:{
      bno:Number(req.body.bno),
      title:req.body.title,
      content:req.body.content,
      writer:req.body.writer
    }
  };

  docClient.put(params,function(err,data){
    if(err){
      console.log(err);
      res.send({
        success: false,
        message: 'Error: Server error'
      });
    } else{
      console.log('data', data);
      const {Items} = data;
      res.render('/data.ejs')
    }
  });
});

  app.get('/list', (req,res,next) => {
    AWS.config.update(config.aws_remote_config);
    const docClient = new AWS.DynamoDB.DocumentClient();
    const params = {
      TableName: config.aws_table_name
    };

    docClient.scan(params, function(err, data){
      if(err){
        res.send({
          success: false,
          message: 'Error: Server error'
        });
      } else {
        const { Items } = data;
        res.send({
          Items
        });
        for (var i=0; i<Items.length;i++){
          Arraybno.push(Number(Items[i]['bno']));
          Arraytitle.push(Items[i]['title']);
          Arraycontent.push(Items[i]['content']);
          Arraywriter.push(Items[i]['writer']);
        }
      }
    });
  }); //

  app.get('/data', function(req,res){
    res.render('data.ejs', {'bno':Arraybno, 'title':Arraytitle, 'content':Arraycontent, 'writer':Arraywriter}, function(err, html){
      if(err){
        console.log(err)
      }
      res.end(html)
    })
  })

  // app.post('/BoardWriteBack', (req, res, next) => {
  //   AWS.config.update(config.aws_remote_config);
  //   const docClient = new AWS.DynamoDB.DocumentClient();
  //   const params = {
  //     TableName: config.aws_table_name,
  //     Item:{
  //       bno:Number(req.body.bno),
  //       title:req.body.title,
  //       content:req.body.content,
  //       writer:req.body.writer
  //     }
  //   };

  app.get('/BoardWrite', function(req, res){
    res.render('BoardWrite.html')
  })
